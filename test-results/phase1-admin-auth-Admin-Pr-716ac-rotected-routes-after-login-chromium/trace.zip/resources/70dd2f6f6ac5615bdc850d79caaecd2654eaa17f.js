(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_7d173dfa._.js",
  "static/chunks/a505b_xlsx_xlsx_mjs_08f6857f._.js",
  "static/chunks/node_modules__pnpm_74a44148._.js"
],
    source: "dynamic"
});
