(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_[locale]_admin_categories_3949dd6f._.js",
  "static/chunks/node_modules__pnpm_8cf95f61._.js"
],
    source: "dynamic"
});
