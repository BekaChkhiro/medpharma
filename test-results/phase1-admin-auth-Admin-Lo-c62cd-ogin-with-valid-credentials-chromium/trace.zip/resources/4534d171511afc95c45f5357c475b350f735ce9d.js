(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[next]_internal_font_google_be385945._.css",
  "static/chunks/node_modules__pnpm_710f2bec._.js"
],
    source: "dynamic"
});
