(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_eaf37248._.js",
  "static/chunks/node_modules__pnpm_2499f19d._.js"
],
    source: "dynamic"
});
