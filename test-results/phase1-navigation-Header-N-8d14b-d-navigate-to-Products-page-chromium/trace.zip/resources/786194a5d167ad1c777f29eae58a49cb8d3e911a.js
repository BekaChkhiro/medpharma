(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_eeee92e2._.js",
  "static/chunks/node_modules__pnpm_917adb64._.js"
],
    source: "dynamic"
});
