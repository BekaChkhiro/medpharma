(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_7f65fc48._.js",
  "static/chunks/node_modules__pnpm_8c7f4a2b._.js"
],
    source: "dynamic"
});
